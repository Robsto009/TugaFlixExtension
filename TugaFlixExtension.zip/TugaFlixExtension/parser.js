function getMovies(document) {
    let movies = [];
    
    // Seleciona todos os blocos de filmes
    let elements = document.querySelectorAll('.movie-details');
    
    elements.forEach(e => {
        let title = e.querySelector('h3') ? e.querySelector('h3').textContent.trim() : "";
        let urlElement = e.querySelector('a[href*="/filme"]'); // link direto do filme
        let url = urlElement ? urlElement.href : "";
        let poster = e.querySelector('img') ? e.querySelector('img').src : "";
        
        movies.push({
            title: title,
            url: url,
            poster: poster
        });
    });
    
    return movies;
}